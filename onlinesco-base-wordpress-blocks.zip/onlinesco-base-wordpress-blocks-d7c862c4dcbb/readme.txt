

Open Sans Font
Copyright 2020 The Open Sans Project Authors (https://github.com/googlefonts/opensans) 
This Font Software is licensed under the SIL Open Font License, Version 1.1. This license is available with a FAQ at: https://scripts.sil.org/OFL 
License URL: http://scripts.sil.org/OFL 
Source: http://www.google.com/get/noto/
-- End of Open Sans Font credits --
