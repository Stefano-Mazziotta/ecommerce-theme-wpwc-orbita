<?php
/**
 * Header
 *
 */
 get_template_part('page-templates/head'); 

    // Menú Header Back-end.
        /*
        $menu_nav = wp_nav_menu( array(
            'theme_location' => 'main-nav',
            'echo' => FALSE,
            'container' => FALSE,
            'fallback_cb' => '__return_false'
        ));
        */
    // 
 
 ?>

<body class="custom-page-template">
<?php wp_body_open(); ?>

    <?php // Aqui va el <header> ?>