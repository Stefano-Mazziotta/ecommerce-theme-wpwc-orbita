        <?php
        /**
         * Footer
         *
         * La función wp_footer permite que Wordpress o ciertos plugins incluya código en ese espacio.
         *
         */
        ?>

        <?php // Acá va el <footer> ?>

        <?php wp_footer(); ?>

    </body>
</html>