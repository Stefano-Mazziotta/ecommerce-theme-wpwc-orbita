# Wordpress Blocks

Este theme de Onlines. contiene todo el material de referencia que necesitas para comenzar a construir un theme de Wordpress basado en bloques.

* Un archivo `theme.json` con estilos y configuración general.
* `functions.php` con algunas configuraciones básicas.
* ` style.css` para configurar el tema.
* Una hoja de estilo separada con todas las alineaciones front-end que necesitará.
* Un `index.php` vacío.
* Instalación de plugins requeridos.

## A futuro

* Librería de patterns.